#include <SFML/Graphics.hpp>
#include <iostream>
#include "game.h"

int main()
{
    Game game;

    game.menu();

    return 0;
}